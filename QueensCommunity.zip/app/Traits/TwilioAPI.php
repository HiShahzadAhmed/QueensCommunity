<?php

namespace App\Traits;
use Twilio\Rest\Client;

trait TwilioAPI
{
	public function sendMessage($message, $recipients)
    {
        $account_sid = "AC5b19ed7ea7fa0242a8e081ebf96b861d";
        $auth_token = "70c7ac032f475079caf6fc75d4b990ea";
        $twilio_number = "+14704102796";
        $client = new Client($account_sid, $auth_token);
        $client->messages->create($recipients,
                ['from' => $twilio_number, 'body' => $message] );
    }
}
