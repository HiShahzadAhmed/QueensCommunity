@extends('layouts.admin')
@section('title','Dashboard')
@section('heading','Dashboard')


@section('content')

<div class="card">
    <div class="card-header">
        Dashboard
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-sm-12">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Amet quasi quis culpa maiores et ab voluptatem iste, non laborum commodi
                tempora accusamus suscipit error beatae explicabo porro. Voluptatum, ipsa beatae.
            </div>
        </div>
    </div>
</div>

@endsection

