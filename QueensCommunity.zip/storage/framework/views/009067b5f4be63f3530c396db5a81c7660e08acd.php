﻿
<?php $__env->startSection('title', 'Questions'); ?>




<?php $__env->startSection('content'); ?>
<div class="main-content-area">

    
    <section class="pt-3 white">
      <div class="container">
        <div class="row">
          
          <div class="col-sm-12 col-xs-12 col-md-4 mb-4">
            <?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          
          </div>
          
          <div class="col-sm-12 col-md-8 mt-4">


            <div id="accordion" class="questions-section">

              <?php $__currentLoopData = Auth::User()->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card mb-4 card-help">
                <div class="card-header">
                  <h5 class="mb-0">
                    <h4  data-toggle="collapse" data-target="#<?php echo e($loop->iteration); ?>collapseOne" aria-expanded="true" aria-controls="<?php echo e($loop->iteration); ?>collapseOne"><?php echo e($question->title); ?></h4>
                  </h5>
                </div>

                <div id="<?php echo e($loop->iteration); ?>collapseOne" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <?php echo e($question->detail); ?>

                    <hr>
                    <div class="row">
                      <div class="col-sm-6 text-left">
                          <h4>Category: <strong><?php echo e($question->category); ?></strong></h4>
                          <h4>Tags: <strong><?php echo e($question->tags); ?></strong></h4>
                      </div>
                      <div class="col-sm-6 text-right">
                        <div class="btn-group mt-3">
                          <a href="<?php echo e(route('question.detail', $question->slug)); ?>" class="btn btn-sm btn-info">More detail</a>
                          <a href="<?php echo e(route('user.edit.question', base64_encode($question->id))); ?>" class="btn btn-sm btn-success">Edit</a>
                          <a href="<?php echo e(route('user.remove.question', base64_encode($question->id))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              

            </div>

          </div>




          <div class="clearfix"></div>
        </div>
      </div>
      <!-- end container -->
    </section>
    <!-- =-=-=-=-=-=-= Post QuestionEnd =-=-=-=-=-=-= -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\forum\resources\views/user/questions/questions.blade.php ENDPATH**/ ?>