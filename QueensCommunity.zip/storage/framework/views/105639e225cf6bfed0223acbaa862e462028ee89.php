
<?php $__env->startSection('title','video Management'); ?>
<?php $__env->startSection('heading','video Management'); ?>
<?php $__env->startSection('css'); ?>
<style>
    .ck-editor__editable
    {
        min-height: 30vw !important;
    }
    .ck-file-dialog-button
    {
        display: none !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">


        <div class="col-sm-12">
            <div class="card">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <?php if((isset($video))): ?>
                                <form action="<?php echo e(route('admin.videos.update',$video->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                            <?php else: ?>
                                <form action="<?php echo e(route('admin.videos.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    <fieldset class="form-group">
                                        <label for="basicInput">Title</label>
                                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e($video->title ?? ''); ?>" required>
                                    </fieldset>
                                </div>
                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    <fieldset class="form-group">
                                        <label for="basicInput">URL</label>
                                        <input type="text" class="form-control" placeholder="ETUacdj8DJs" maxlength="11" name="url" required value="<?php echo e($video->url ?? ''); ?>">
                                    </fieldset>
                                </div>
                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    
                                    <fieldset  class="form-group">
                                        <label>Category</label>
                                        <select class="questions-category form-control dynamic" id="category"  data-dependent="sub_category" name="category" >
                                            <?php if(isset($video->category)): ?>
                                            <option value="<?php echo e($video->category); ?>" hidden><?php echo e($video->category); ?></option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option hidden>Select Category</option>
                                            <option value="<?php echo e($data->category); ?>"><?php echo e($data->category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </fieldset>
                                </div>
                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    <fieldset  class="form-group">
                                        <label>Sub Category</label>
                                        <select class="questions-category form-control" id="sub_category"  name="sub_category" >
                                            <?php if(isset($video->sub_category)): ?>
                                            <option value="<?php echo e($video->sub_category); ?>" hidden><?php echo e($video->sub_category); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </fieldset>
                                        <?php echo e(csrf_field()); ?>

                                        
                                </div>
                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    <fieldset class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" placeholder="Description" name="description" required><?php echo e($video->description ?? ''); ?></textarea>
                                    </fieldset>
                                </div>

                                <div class="col-xl-12 col-md-12 col-12 mb-1">
                                    <fieldset class="form-group pull-right">
                                        <button class="btn btn-relief-primary" type="submit">Save Changes</button>
                                    </fieldset>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    $(document).ready(function(){
     $('.dynamic').change(function(){
      if($(this).val() != '')
      {
       var select = $(this).attr("id");
       var value = $(this).val();
       var dependent = $(this).data('dependent');
       var _token = $('input[name="_token"]').val();
       $.ajax({
         url:"<?php echo e(route('category.fetch')); ?>",
         method:"POST",
        data:{select:select, value:value, _token:_token, dependent:dependent},
        success:function(result)
        {
         $('#'+dependent).html(result);
        }

       })
      }
     });

     $('#category').change(function(){
      $('#sub_category').val('');
     });

    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\QueensCommunity\resources\views/admin/videos/add-edit.blade.php ENDPATH**/ ?>