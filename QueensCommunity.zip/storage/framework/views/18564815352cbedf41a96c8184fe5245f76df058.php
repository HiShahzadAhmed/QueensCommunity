<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto mt-0"><a class="navbar-brand mt-0" style="padding-top: 0px;" href="">
                    <div class="brand-logo" style="background-image: url('<?php echo e(asset($setting['favicon'] ?? '')); ?>');"></div>
                    <h2 class="brand-text mb-0"><img src="<?php echo e(asset($setting['logo'] ?? '')); ?>" style="width: 120px;" alt=""></h2>
                </a></li>
            <!--    <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="icon-disc"></i></a></li>
        -->
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.dashboard')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="feather icon-home"></i>Dashboard</a></li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_questions')): ?>
                <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.questions.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.questions.index')); ?>"><i class="feather icon-help-circle"></i>Questions</a></li>
            <?php endif; ?>

            <li class=" navigation-header"><span>Others</span></li>
            <li class="nav-item"><a href=""><i class="feather icon-users"></i>Members</a></li>
            <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.setting.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.setting.index')); ?>"><i class="feather icon-settings"></i>Settings</a></li>



            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_roles')): ?>
                <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.roles.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.roles.index')); ?>"><i class="feather icon-zap"></i>Roles</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_teams')): ?>
                <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.teams.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.teams.index')); ?>"><i class="feather icon-users"></i>Teams</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_blogs')): ?>
                <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.blogs.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.blogs.index')); ?>"><i class="feather icon-book"></i>Blogs</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_videos')): ?>
                <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.videos.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.videos.index')); ?>"><i class="feather icon-video"></i>Videos</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse_category')): ?>
            <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.categories.index')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.categories.index')); ?>"><i class="feather icon-list"></i>Category</a></li>
            <?php endif; ?>


            <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.inquiries')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.inquiries')); ?>"><i class="feather icon-info"></i>Inquiries</a></li>
            






        </ul>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\QueensCommunity\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>