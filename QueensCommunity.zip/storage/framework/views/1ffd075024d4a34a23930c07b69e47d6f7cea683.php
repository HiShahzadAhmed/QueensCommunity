
<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<section class="white padding-bottom-80">
    <div class="container">
        <div class="row">

 <!-- Content Area Bar -->
 <div class="col-md-12 col-sm-12 col-xs-12">
    <!-- title-section -->
    <div class="main-heading margin-top-30 text-center">
        <h2>All Polls</h2>
        <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span>
        </div>
    </div>
    <!-- End title-section -->
    <div class="panel-body">
        <div class="tab-content">
            <?php echo e(csrf_field()); ?>

            <div class="" id="post_pools">

            </div>

        </div>
    </div>
</div>

</div>
</div>
<!-- end container -->
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    $(document).ready(function(){

     var _token = $('input[name="_token"]').val();

     load_data('', _token);

     function load_data(id="", _token)
     {
      $.ajax({
       url:"<?php echo e(route('loadmore.load_pools')); ?>",
       method:"POST",
       data:{id:id, _token:_token},
       success:function(data)
       {
        $('#load_more_button').remove();
        $('#post_pools').append(data);
       }
      })
     }

     $(document).on('click', '#load_more_button', function(){
      var id = $(this).data('id');
      $('#load_more_button').html('<b>Loading...</b>');
      load_data(id, _token);
     });

    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\QueensCommunity\resources\views/user/pools/view_pools.blade.php ENDPATH**/ ?>