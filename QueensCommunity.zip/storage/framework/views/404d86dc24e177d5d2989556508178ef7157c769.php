﻿
<?php $__env->startSection('title', 'Post Question'); ?>




<?php $__env->startSection('content'); ?>
<div class="main-content-area">

    <section class="pt-3 white">
      <div class="container">
        <div class="row">

          <div class="col-sm-12 col-xs-12 col-md-4 mb-4">
            <?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          </div>

          <div class="col-sm-12 col-md-8 mt-4 ">

            <div class="box-panel">

              <h2>Post Your Question</h2>
              <p>Adding accurate and easy woring question will help you get better answers and more views.</p>
              <hr>
              <!-- form login -->
              <form class="margin-top-40" method="POST" action="<?php echo e(route('user.store.question')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Question Title</label>
                  <input type="text" name="title" placeholder="Question title" class="form-control" required="">
                </div>
                <div class="form-group">
                  <label>Category</label>
                  <select class="questions-category form-control dynamic" id="category"  data-dependent="sub_category" name="category" style="height: 55px">
                   <option selected hidden>Select Category</option>
                    <?php $__currentLoopData = categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($data->category); ?>"><?php echo e($data->category); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                    <label>Sub Category</label>
                    <select class="questions-category form-control" id="sub_category"  name="sub_category" style="height: 55px">
                        <option value="" hidden selected>Select Sub Category</option>
                    </select>
                  </div>
                  <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label>Tags</label>

                  <input type="text" id="tags" placeholder="nature, beauty, health" name="tags" class="form-control" data-role="tagsinput" required="">
                </div>

                <div class="form-group">
                  <label>Question Detials</label>
                  <textarea cols="12" rows="12" placeholder="Post Your Question Details Here....." id="message" name="detail" class="form-control" required=""></textarea>
                </div>

                <div class="form-group text-right mb-0">
                  <input type="checkbox" name="is_anonymous" value="1">
                  <label>Post anonymously</label>
                </div>

                <button type="submit" class="btn btn-primary pull-right">Publish Your Question</button>

              </form>
              <!-- form login -->

            </div>
          </div>




          <div class="clearfix"></div>
        </div>
      </div>
      <!-- end container -->
    </section>
    <!-- =-=-=-=-=-=-= Post QuestionEnd =-=-=-=-=-=-= -->
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    $(document).ready(function(){
     $('.dynamic').change(function(){
      if($(this).val() != '')
      {
       var select = $(this).attr("id");
       var value = $(this).val();
       var dependent = $(this).data('dependent');
       var _token = $('input[name="_token"]').val();
       $.ajax({
         url:"<?php echo e(route('category.fetch')); ?>",
         method:"POST",
        data:{select:select, value:value, _token:_token, dependent:dependent},
        success:function(result)
        {
         $('#'+dependent).html(result);
        }

       })
      }
     });

     $('#category').change(function(){
      $('#sub_category').val('');
     });



    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\QueensCommunity\resources\views/user/questions/post_question.blade.php ENDPATH**/ ?>